# GTBotLinux
A GrowtopiaBot can run on Linux, GrowtopiaBot Made by DrOreo002 and GrowtopiaNoobs<br />
i just make support linux<br />
Update = Now gtbot Support login to real gt (thanks to atipls)
# Warning
GTBotLinux is still experiment, if you get error, dont forget to screenshot and post to issue<br />
# How to build
<!---
If you use Termux, please use termux.sh<br />
To run = bash termux.sh<br />
If you use Linux, please use linux.sh<br />
To run = bash linux.sh<br />
If you already install dependencies (build-essential)<br />
To compile the source code = bash build.sh-->
Termux<br />
1. pkg update -y && pkg upgrade -y
2. pkg install git nano
3. git clone https://github.com/GuckTubeYT/GTBotLinux
4. cd GTBotLinux
5. bash termux.sh
6. dont forget to edit config.json, Command = nano config.json
7. ./gtbot

Linux<br />
1. sudo apt update -y && sudo apt upgrade -y
2. sudo apt install git nano
3. git clone https://github.com/GuckTubeYT/GTBotLinux
4. cd GTBotLinux
5. bash linux.sh
6. dont forget to edit config.json, Command = nano config.json
7. ./gtbot
# Setting
Just edit the config.json<br />
To edit = nano config.json
# Join
Join my Discord Group = https://bit.ly/guckproject
